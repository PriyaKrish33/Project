import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { TableComponent } from './table/table.component';
import { UserlandComponent } from './userland/userland.component';
import { AdminlandComponent } from './adminland/adminland.component';


const routes: Routes = [
 {path:'',component:UserSignupComponent},
 {path:'mentor',component:MentorSignupComponent},
 {path:'table',component:TableComponent},
 {path:'userland',component:UserlandComponent},
 {path:'admin',component:AdminlandComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
