import { Injectable } from '@angular/core';
import { User } from './user';
import { HttpClient } from '@angular/common/http';
import { Mentor } from './mentor';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class ServService {

  constructor(private httpClient:HttpClient) {}
  public saveUser(user: User) {  
    return this.httpClient.post('http://localhost:8080/'+'user', user);  
  }
 public saveMentor(mentor: Mentor) {  
     return this.httpClient.post('http://localhost:8081/mentors', mentor);  
}
public findmentorlist()
{
 return this.httpClient.get('http://localhost:8084/'+'findmentorlist');
}
public findtechnology(technology:string) {
  return this.httpClient.get(`http://localhost:8084/findtechnology/${technology}`);
}
public findcurrent(username:string){
  return this.httpClient.get(`http://localhost:8080/findcurrent/${username}`);
}
public findcompleted(username:string){
  return this.httpClient.get(`http://localhost:8080/findcompleted/${username}`);
}
userblock(username:string){
  return this.httpClient.get(`http://localhost:8089/userblock/${username}`);

}
userunblock(username:string){
  return this.httpClient.get(`http://localhost:8089/userunblock/${username}`);

}
findmentor(){
  return this.httpClient.get('http://localhost:8089/findmentor');
}
finduser(){
  return this.httpClient.get('http://localhost:8089/finduser')
}
}
