import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';
import { User } from '../user';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {
  user : User;
  constructor(private route: ActivatedRoute, private router: Router,private service:ServService) { 
    this.user = new User();
  }

  ngOnInit() {
    
  }
  onSubmit() {
    this.service.saveUser(this.user).subscribe();
    // this.gotoUserList();
  }
  // gotoUserList() {
  //   this.router.navigate(['/save']);
  // }

}
