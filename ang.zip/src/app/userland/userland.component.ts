import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-userland',
  templateUrl: './userland.component.html',
  styleUrls: ['./userland.component.css']
})
export class UserlandComponent implements OnInit {
  public show:boolean = true;
  public current:boolean = false;
  public completed:boolean = false;
  public body:boolean = true;
  public bar:boolean = false;
  private trainers=[];
  private currdata=[];
  private compdata=[];
  public searchText;
  username: string;
  constructor(private service:ServService, private router:ActivatedRoute) { }

  ngOnInit() {
    this.service.findmentorlist().subscribe(data =>{  this.trainers =data as string[]; });
    this.username=this.router.snapshot.paramMap.get('username');
  }
  showSearch() {
    this.completed=false;
    this.current=false;
    this.bar=false;
    this.service.findtechnology(this.searchText).subscribe(data => this.trainers= data as string[]);
  }
  search() {
    this.body=true;
    this.completed=false;
    this.current=false;
    this.bar=false;
    this.show=true;
    
  }
  showCurrent() {
    this.body=false;
    this.current=true;
    this.completed=false;
    this.bar=false;
    this.show=false;
    this.service.findcurrent('hello123@gmail.com').subscribe(data => this.currdata=data as string[]);
  }
  showCompleted() {
    this.body=false;
    this.current=false;
    this.completed=true;
    this.bar=false;
    this.service.findcompleted('hello123@gmail.com').subscribe(data => this.compdata=data as string[]);

  }
  showBar() {
    this.bar=true;
    this.show=false;
    this.current=false;
    this.completed=false;
    this.show=false;
  }

}
