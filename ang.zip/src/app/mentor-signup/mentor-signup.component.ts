import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  mentor:Mentor;
  constructor(private route: ActivatedRoute, private router: Router,private service:ServService) {
    this.mentor = new Mentor();
   }

  ngOnInit() {
  }
  onSubmit() {
    this.service.saveMentor(this.mentor).subscribe();
    // this.gotoUserList();
  }
}
