import { Time } from '@angular/common';

export class Mentor {
    public  username:String;
	public firstname:String ;
	public  lastname:String;
	public contactnumber:number;
	public  experience:number;
	public  facilities:String;
	public  starttime:Time;
	public  endtime:Time;
}
