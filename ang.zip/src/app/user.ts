export class User {
        public username:String;
        public password:String;
}

