import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  public show:boolean = true;
private trainers=[];
  constructor(private service:ServService) { }

  ngOnInit() {
    this.service.findmentorlist().subscribe(data =>{  this.trainers =data as string[]; });

  }
  // toggle() {
  
  //   this.show= false;
  // }
  // search() {
  //   this.show=true;
  // }
}
