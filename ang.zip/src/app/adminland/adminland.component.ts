import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-adminland',
  templateUrl: './adminland.component.html',
  styleUrls: ['./adminland.component.css']
})
export class AdminlandComponent implements OnInit {
  trainers: string[];
  users: string[];

  constructor(private service:ServService) { }

  ngOnInit() {
    this.service.findmentor().subscribe(data =>{ this.trainers =data as string[]; });
    this.service.finduser().subscribe(data =>{ this.users =data as string[]; });
  }
  delete(username){
  
    this.service.userblock(username).subscribe();
      
  }
  unblock(username){
    this.service.userunblock(username).subscribe();
  }

}
