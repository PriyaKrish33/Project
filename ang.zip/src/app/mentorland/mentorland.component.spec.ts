import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorlandComponent } from './mentorland.component';

describe('MentorlandComponent', () => {
  let component: MentorlandComponent;
  let fixture: ComponentFixture<MentorlandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorlandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorlandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
