import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorland',
  templateUrl: './mentorland.component.html',
  styleUrls: ['./mentorland.component.css']
})
export class MentorlandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
