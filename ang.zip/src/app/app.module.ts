import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule}   from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { HttpClientModule } from '@angular/common/http';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { TableComponent } from './table/table.component';
import { UserlandComponent } from './userland/userland.component';
import { MentorlandComponent } from './mentorland/mentorland.component';
import { AdminlandComponent } from './adminland/adminland.component';

@NgModule({
  declarations: [
    AppComponent,
    UserSignupComponent,
    MentorSignupComponent,
    TableComponent,
    UserlandComponent,
    MentorlandComponent,
    AdminlandComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
