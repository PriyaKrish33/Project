export class Usersign {
    username:string;
    firstname:string;
    lastname:string;
    password:string;

}
