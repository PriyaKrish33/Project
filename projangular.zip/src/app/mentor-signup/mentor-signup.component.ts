import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { MentorserviceService } from '../mentorservice.service';
import { Mentor } from '../mentor';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {
  mentordetails : boolean;
  mentortech : boolean;
  register : boolean;
  mentortime : boolean; 
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  technology = [];
  musername : String;
  registerForm: FormGroup;
  submitted = false;
  mntr : Mentor = new Mentor();
  constructor(private formBuilder: FormBuilder,private router:Router, private mentorService:MentorserviceService ) { }


  ngOnInit() {
    this.mentordetails=true;
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      exp:['', Validators.required],
      phone:['', Validators.required],
      tech:['', Validators.required],
      startTime:['', Validators.required],
      endTime:['', Validators.required]    
    });
  }
  get f() { return this.registerForm.controls; }
  save() {
    this.musername = this.mntr.username;
    this.mentorService.createMentor(this.mntr)
      .subscribe(data => console.log(data), error => console.log(error));
    this.mntr = new Mentor();
  }
  onSubmit(data) {
    this.submitted = true;
    // if (this.registerForm.invalid) {
    //     return;
    //   }
    
      this.save();


      this.mentorService.getAdminTechnologyList().subscribe(data =>{  
         this.dropdownList = data as string[];  
              })
            this.dropdownSettings= {
            singleSelection: false,
            idField: 'id',
            textField: 'technology',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            // itemsShowLimit: 3,
            allowSearchFilter: true
          };

          this.mentortech = true;
          this.mentordetails=false;


   }

   onItemSelect(item: any) {
      this.technology.push(item);
      console.log(item);
    }
    onSelectAll(items: any) {
       this.technology = items;
      console.log(items);
    }


    addTech(){
       for(let i of this.technology)
       {
         this.mentorService.saveTechnology(this.musername,i.technology)
         .subscribe(data => console.log(data), error => console.log(error));
       }

       this.register = true;
       this.mentortech =false;
       this.mentordetails=false;
       this.router.navigateByUrl('/mentorLogin');

    }


    // this.router.navigateByUrl('/mentorLogin');
  }
