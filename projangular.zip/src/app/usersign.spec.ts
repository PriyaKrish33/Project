import { Usersign } from './usersign';

describe('Usersign', () => {
  it('should create an instance', () => {
    expect(new Usersign()).toBeTruthy();
  });
});
