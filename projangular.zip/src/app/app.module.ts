import {ReactiveFormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorLandComponent } from './mentor-land/mentor-land.component';
import { AdminLandComponent } from './admin-land/admin-land.component';
import { UserLandComponent } from './user-land/user-land.component';
import { ProfileComponent } from './profile/profile.component';
import { AdminEditComponent } from './admin-edit/admin-edit.component';
import { PayslipComponent } from './payslip/payslip.component';
import { MainComponent } from './main/main.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { UserProposeComponent } from './user-propose/user-propose.component';
import { HttpClientModule } from '@angular/common/http';
import { FilterPipe } from './filter.pipe';
import { LoginComponent } from './login/login.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  declarations: [
    AppComponent,
    UserSignUpComponent,
    MentorSignupComponent,
    MentorLandComponent,
    AdminLandComponent,
    UserLandComponent,
    ProfileComponent,
    AdminEditComponent,
    PayslipComponent,
    MainComponent,
    UserLoginComponent,
    MentorLoginComponent,
    UserProposeComponent,
    FilterPipe,
    LoginComponent
  ],
  imports: [
    BrowserModule, FormsModule,
    AppRoutingModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule.forRoot()
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
