import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorLandComponent } from './mentor-land.component';

describe('MentorLandComponent', () => {
  let component: MentorLandComponent;
  let fixture: ComponentFixture<MentorLandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorLandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorLandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
