import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mentor-land',
  templateUrl: './mentor-land.component.html',
  styleUrls: ['./mentor-land.component.css']
})
export class MentorLandComponent implements OnInit {
  public show:boolean = true;
  public current:boolean = false;
  public completed:boolean = false;
  username: string;
  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    this.username = this.route.snapshot.paramMap.get('id');
  }
  search() {
    this.show=true;
    this.completed=false;
    this.current=false;
  
  }
  showCurrent() {
    this.show=false;
    this.current=true;
    this.completed=false;
    
  }
  showCompleted() {
    this.show=false;
    this.current=false;
    this.completed=true;
    

  }

}
