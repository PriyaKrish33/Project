import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-land',
  templateUrl: './admin-land.component.html',
  styleUrls: ['./admin-land.component.css']
})
export class AdminLandComponent implements OnInit {
  arrData: string[];
  username: string;
  constructor(private httpService: HttpClient, private route:ActivatedRoute) { }


  ngOnInit() {
    this.username = this.route.snapshot.paramMap.get('id');
    this.httpService.get('./assets/data.json').subscribe(
      data => {
        this.arrData = data as string [];	 // FILL THE ARRAY WITH DATA.
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

}
