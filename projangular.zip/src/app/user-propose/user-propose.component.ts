import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { MentorserviceService } from '../mentorservice.service';

@Component({
  selector: 'app-user-propose',
  templateUrl: './user-propose.component.html',
  styleUrls: ['./user-propose.component.css']
})
export class UserProposeComponent implements OnInit {
  public show:boolean = true;
  public current:boolean = false;
  public completed:boolean = false;
  public body:boolean = true;
  public bar:boolean = false;
  private trainers=[];
  private currdata=[];
  private compdata=[];
  public searchText;
  username: string;
  constructor(private route:ActivatedRoute, private userservice:UserserviceService,private mentorservice:MentorserviceService) { }

  ngOnInit() {
    this.userservice.getMentorList().subscribe(data =>{  this.trainers =data as string[]; });
    // this.username=this.userservice.snapshot.paramMap.get('username');
  }
  showSearch() {
  
    this.show= false;
    this.completed=false;
    this.current=false;
    this.bar=false;
  
  }
  search() {
    this.body=true;
    this.completed=false;
    this.current=false;
    this.bar=false;
    this.show=true;
  }
  showCurrent() {
    this.body=false;
    this.current=true;
    this.completed=false;
    this.bar=false;
    this.show=false;
    this.userservice.getUserCurrentList('hello123@gmail.com').subscribe(data => this.currdata=data as string[]);
  }
  showCompleted() {
    this.body=false;
    this.current=false;
    this.completed=true;
    this.bar=false;
    this.userservice.getUserCompletedList('hello123@gmail.com').subscribe(data => this.currdata=data as string[]);

  }
  showBar() {
    this.bar=true;
    this.show=false;
    this.current=false;
    this.completed=false;
    this.show=false;
  }

}
