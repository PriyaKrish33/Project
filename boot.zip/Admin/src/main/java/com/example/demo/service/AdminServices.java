package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.BlockUser;
import com.example.demo.model.Mentor;
import com.example.demo.model.Payment;
import com.example.demo.model.Role;
import com.example.demo.model.Technology;
import com.example.demo.model.User;
import com.example.demo.model.UserDetails;
import com.example.demo.repository.BlockUserRepository;
import com.example.demo.repository.MentorRepository;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.TechnologyRepository;
import com.example.demo.repository.UserDetailsRepository;
import com.example.demo.repository.UserRepository;

@Service
public class AdminServices {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
    private PaymentRepository paymentRepository;
	@Autowired
   private RoleRepository roleRepository;
	@Autowired
private TechnologyRepository technologyRepository;
	@Autowired
private UserDetailsRepository userDetailsRepository;
	@Autowired
private UserRepository userRepository;
	
	@Autowired
	private BlockUserRepository blockuserRepository;
	
	 public List<Technology> findTechnology(){
		 return (List<Technology>) technologyRepository.findAll();
		 
	 }
	 public List<Payment> findPayment(){
		 return (List<Payment>) paymentRepository.findAll();
		 
	 }
	 public List<User> findUser(){
		 return (List<User>) userRepository.findAll();
		 
	 }
	 public List<Mentor> findMentor(){
		 return (List<Mentor>) mentorRepository.findAll();
		 
	 }
	 public void saveUser(String username,String password) {
			User u=new User();
			u.setUsername(username);
			u.setPassword(password);
			int id=2;
			Role r=roleRepository.findById(id);
			u.setRole(r);
			
			userRepository.save(u);
			
		}
	 
	 public void bUser(String username) {
			User u=userRepository.findByUsername(username);
			BlockUser bu = new BlockUser();
			bu.setUsername(u.getUsername());
			bu.setPassword(u.getPassword());
			bu.setRole(u.getRole());
			blockuserRepository.save(bu);
			
			userRepository.deleteById(username);			
		}
	 
	 public List<BlockUser> findBlockList(){
		 return (List<BlockUser>) blockuserRepository.findAll();
		 
	 }
	 
	 public void unbUser(String username) {
		 BlockUser  bu=blockuserRepository.findByUsername(username);
			User u = new User();
			u.setUsername(bu.getUsername());
			u.setPassword(bu.getPassword());
			u.setRole(bu.getRole());
			userRepository.save(u);
			
			blockuserRepository.deleteById(username);			
		}

}
