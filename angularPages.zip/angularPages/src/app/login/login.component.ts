import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  usr:User=new User();
  constructor(private formBuilder: FormBuilder,private router:Router,private userService: UserserviceService) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
    uname: ['', [Validators.required]],
      passwd: ['', [Validators.required, Validators.minLength(8)]]
  });
  }
  get f() { return this.registerForm.controls; }
  onSubmit(data) {
   

    // stop here if form is invalid
    // if (this.registerForm.invalid) {
    //     return;
    // }
    //  console.log(data.uname);
    //   if (data.uname == "systemadmin" && data.passwd == "admin123") {
    //      alert("Login Successful");
    //     this.router.navigate(['propose'])
    //   }
      
    this.userService.getUser(data.uname).subscribe(value =>{  
      this.usr = value})  

      if(this.usr.password == data.passwd)
      {

         
         if(this.usr.role.id == 3)
         {
            this.router.navigate(['propose',{ id: data.uname}])
         }
         if(this.usr.role.id == 2)
         {
            this.router.navigate(['mentLand',{ id: data.uname}])
         }
         if(this.usr.role.id == 1)
         {
            this.router.navigate(['admLand'])
         }
         

}

  }
}
