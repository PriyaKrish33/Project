import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-admin-land',
  templateUrl: './admin-land.component.html',
  styleUrls: ['./admin-land.component.css']
})
export class AdminLandComponent implements OnInit {
  public show:boolean = true;
  public current:boolean = false;
  public completed:boolean = false;
  public body:boolean = true;
  public bar:boolean = false;
  username: string;
  private trainers=[];
  private currdata=[];
  private compdata=[];
  private users=[];
  constructor(private userservice :UserserviceService, private route:ActivatedRoute) { }


  ngOnInit() {
    this.userservice.getMentorSearchList().subscribe(data =>{  this.trainers =data as string[]; });
    this.userservice.getUserSearchList().subscribe(data =>{  this.users =data as string[]; });
  }
  search() {
    this.body=true;
    this.completed=false;
    this.current=false;
    this.bar=false;
    this.show=true;
  }
  showCurrent() {
    this.body=false;
    this.current=true;
    this.completed=false;
    this.bar=false;
    this.show=false;
    this.userservice.getTechnology().subscribe(data => this.currdata= data as string[]);
  }
  showCompleted() {
    this.show=false;
    this.body=false;
    this.current=false;
    this.completed=true;
    this.bar=false;
    this.userservice.getPayment().subscribe(data => this.compdata=data as string[]);

  }
  block(username){
    this.userservice.blockUserService(username).subscribe();

  }
  unblock(username)
  {
    this.userservice.unblockUserService(username).subscribe();
  }

}
