import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProposeComponent } from './user-propose.component';

describe('UserProposeComponent', () => {
  let component: UserProposeComponent;
  let fixture: ComponentFixture<UserProposeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserProposeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProposeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
