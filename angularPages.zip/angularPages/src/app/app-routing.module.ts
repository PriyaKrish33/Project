import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLandComponent } from './user-land/user-land.component';
import { MainComponent } from './main/main.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { UserProposeComponent } from './user-propose/user-propose.component';
import { MentorLandComponent } from './mentor-land/mentor-land.component';
import { AdminLandComponent } from './admin-land/admin-land.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [
  {path:'',component:UserLandComponent},
  {path:'main',component:MainComponent},
  {path:'userLogin',component:LoginComponent},
  {path:'mentorLogin',component:LoginComponent},
  {path:'adminLogin',component:LoginComponent},
  {path:'userSign',component:UserSignUpComponent},
  {path:'mentorSign',component:MentorSignupComponent},
  {path:'propose',component:UserProposeComponent},
  {path:'mentLand',component:MentorLandComponent},
  {path:'admLand',component:AdminLandComponent},
  {path:'profile',component:ProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
