import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  [x: string]: any;
  private baseUrl = 'http://localhost:8080/api';  
  constructor(private http: HttpClient) { }
  getUser(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/loginuser/${username}`);
  }
  createUser(usersign : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+`/userservice/saveuser`, usersign);
  }
  createUserDetails(usersign: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+`/userservice/saveUserdetails`, usersign);
  }
  // createEmployee(employee: Object): Observable<Object> {
  //   return this.http.post('http://localhost:8086/states', employee);
  // }

 
  getTrainingList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/mentor/findmentorlist`);
  }

  getUserCompletedList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/findcompleted/${username}`);
  }

  getUserCurrentList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/findcurrent/${username}`);
  }


  proposeTrain(id : number,tech : String,username : String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/mentor/proposeTraining/${id}/${tech}/${username}`);
  }

  getUserSearchList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/finduser`);
  }
  getMentorSearchList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/findmentor`);
  }
  getMentorList(){
    return this.http.get(`${this.baseUrl}/courseservice/findmentorlist`);
  }
  getPayment(){
    return this.http.get(`${this.baseUrl}/admin/findpayment`);
  }
  getTechnology(){
    return this.http.get(`${this.baseUrl}/admin/findtechnology`);
  }


  blockUserService(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/blockuser/${username}`);
  }

  getBlockUserList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/blockuserlist`);
  }

  unblockUserService(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/unblockuser/${username}`);
  }

}
