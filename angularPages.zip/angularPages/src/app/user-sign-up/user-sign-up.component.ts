import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { Usersign } from '../usersign';

@Component({
  selector: 'app-user-sign-up',
  templateUrl: './user-sign-up.component.html',
  styleUrls: ['./user-sign-up.component.css']
})
export class UserSignUpComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  usernam:string;
  usr :Usersign= new Usersign();
  constructor(private formBuilder: FormBuilder,private router:Router, private userService:UserserviceService ) { }


  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
  });
  }
  get f() { return this.registerForm.controls; }
  save() {
    this.usernam = this.usr.username;
    // this.userService.createUser(this.usr)
    //   .subscribe(data => console.log(data), error => console.log(error));
    //   this.usr = new Usersign();
      this.userService.createUserDetails(this.usr)
      .subscribe(data => console.log(data), error => console.log(error));
    this.usr = new Usersign();
  }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    // if (this.registerForm.invalid) {
    //     return;
    // }
    this.save();

    this.router.navigateByUrl('/userLogin');

}

}
