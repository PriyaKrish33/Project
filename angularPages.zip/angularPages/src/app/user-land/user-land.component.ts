import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { UserserviceService } from '../userservice.service';


@Component({
  selector: 'app-user-land',
  templateUrl: './user-land.component.html',
  styleUrls: ['./user-land.component.css']
})
export class UserLandComponent implements OnInit {
  searchText : string; 
  private trainers=[];
  public show:boolean = true;
  constructor(private userservice:UserserviceService) { }
    arrData: string[];
  ngOnInit() {
    this.userservice.getMentorList().subscribe(data =>{  this.trainers =data as string[]; });
  }
  toggle() {
  
  this.show= false;
}
search() {
  this.show=true;
}
}


